﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace OTPUtils
{
    public class OTPService
    {

        private  int TimeInvalid = 30;//有效期
        private int PWDLength = 6;//密码长度

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="pwdLength">动态密码长度</param>
        public OTPService(int pwdLength = 6)
        {
            this.PWDLength = pwdLength;
        }

        /// <summary>
        /// 获取动态密码
        /// </summary>
        /// <param name="key">密钥(32位)</param>
        /// <returns></returns>
        public string GetTOTP(string key)
        {
            try
            {
                string secretHex = HexEncodingUtils.Encode(Base32Utils.Decode(key));
                string steps = this.GetSteps();

                return this.GenerateTOTP(secretHex, steps);
            }
            catch (Exception err)
            {
                return "";
            }
        }
    
        private static byte[] GetHMACSHA1(byte[] keyBytes, byte[] text)
        {
            HMACSHA1 hmac = new HMACSHA1(keyBytes);
            return hmac.ComputeHash(text);
        }

        private static  int[] DIGITS_POWER
          // 0 1  2   3    4     5      6       7        8
          = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };
        private string GenerateTOTP(string key, string time)
        {
            int codeDigits = PWDLength;
            string result = "";

            // Get the HEX in a Byte[]
            byte[] msg = HexEncodingUtils.HexStr2Bytes(time);
            byte[] k = HexEncodingUtils.HexStr2Bytes(key);

            byte[] hash = GetHMACSHA1(k, msg);

            // put selected bytes into result int
            int offset = hash[hash.Length - 1] & 0xf;

            int binary =
                    ((hash[offset] & 0x7f) << 24) |
                            ((hash[offset + 1] & 0xff) << 16) |
                            ((hash[offset + 2] & 0xff) << 8) |
                            (hash[offset + 3] & 0xff);

            int otp = binary % DIGITS_POWER[codeDigits];

            result = otp.ToString();
            while (result.Length < codeDigits)
            {
                result = "0" + result;
            }

            return result;
        }
       
        private string GetSteps()
        {
            DateTime _epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan ts = DateTime.UtcNow - _epoch;      
            long T0 = 0;
            long X = TimeInvalid;
            long time = (long)ts.TotalSeconds;          
            string steps = "0";

            long T = (time - T0) / X;
            steps = T.ToString("x").ToUpper();
            while (steps.Length < 16)
                steps = "0" + steps;
        
            return steps;
        }

        /// <summary>
        /// 用于生成二维码的地址(该二维码仅供身份宝使用)
        /// </summary>
        /// <param name="accounts"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetQRCodeUrl(string accounts,string key)
        {
            return $"otpauth://totp/{accounts}?secret={key}";
        }
        
        /// <summary>
        /// 生成密钥
        /// </summary>
        /// <returns></returns>
        public  string GetKey()
        {
            Random random = new Random();
            byte[] salt = new byte[32 / 2];
            random.NextBytes(salt);
            return Base32Utils.Encode(salt);
        }

    }
}
