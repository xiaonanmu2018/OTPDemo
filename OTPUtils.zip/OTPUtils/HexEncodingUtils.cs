﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace OTPUtils
{
    internal static class HexEncodingUtils
    {
        private static char[] HEX_DIGITS = "0123456789abcdef".ToCharArray();

        /**
         * Encodes the provided data as a hexadecimal string.
         */
        public static string Encode(byte[] data)
        {
            StringBuilder result = new StringBuilder(data.Length * 2);
            foreach (byte b in data)
            {
                result.Append(HEX_DIGITS[(b >> 4) & 0x0f]);
                result.Append(HEX_DIGITS[b & 0x0f]);
            }
            return result.ToString();
        }


        public static byte[] HexStr2Bytes(string hex)
        {
            // Adding one byte to get the right conversion
            // Values starting with "0" can be converted
            byte[] bArray = BigInteger.Parse("10"+hex,System.Globalization.NumberStyles.HexNumber).ToByteArray();
        
            // Copy all the REAL bytes, not the "first"
            byte[] ret = new byte[bArray.Length - 1];
            for (int i = 0; i < ret.Length; i++)
                ret[ret.Length-1- i] = bArray[i];
            return ret;
        }


    }
}
